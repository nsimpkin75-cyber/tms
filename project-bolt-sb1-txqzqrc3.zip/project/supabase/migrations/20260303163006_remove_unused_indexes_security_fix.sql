/*
  # Remove Unused Indexes - Security Fix

  1. Purpose
    - Remove indexes that are not being used by queries
    - Reduces database overhead and improves write performance
    - Addresses security advisor warnings about unused indexes

  2. Changes
    - Drops 150+ unused indexes across various tables
    - All indexes use IF EXISTS to prevent errors

  3. Performance Impact
    - Improves INSERT/UPDATE/DELETE performance
    - Reduces storage overhead
    - Maintains all necessary indexes for foreign keys and queries
*/

-- Drop unused indexes
DROP INDEX IF EXISTS idx_reviews_user_id_fkey;
DROP INDEX IF EXISTS idx_moderation_queue_moderator;
DROP INDEX IF EXISTS idx_copilot_functions_category;
DROP INDEX IF EXISTS idx_training_sessions_date;
DROP INDEX IF EXISTS idx_career_development_plans_user_id;
DROP INDEX IF EXISTS idx_review_template_sections_order;
DROP INDEX IF EXISTS idx_one_to_one_scheduled_meetings_completion_status;
DROP INDEX IF EXISTS idx_one_to_one_scheduled_meetings_scheduled_datetime;
DROP INDEX IF EXISTS idx_one_to_one_scheduled_meetings_manager_cycle;
DROP INDEX IF EXISTS idx_values_active;
DROP INDEX IF EXISTS idx_competencies_value;
DROP INDEX IF EXISTS idx_strategic_goals_roadmap_id;
DROP INDEX IF EXISTS idx_training_attendees_training_session_id;
DROP INDEX IF EXISTS idx_business_strategies_created_by;
DROP INDEX IF EXISTS idx_business_strategies_owner_id;
DROP INDEX IF EXISTS idx_career_development_plans_manager_id;
DROP INDEX IF EXISTS idx_career_pathways_user_id;
DROP INDEX IF EXISTS idx_career_plan_milestones_career_plan_id;
DROP INDEX IF EXISTS idx_career_plans_current_job_family_id;
DROP INDEX IF EXISTS idx_career_plans_target_job_family_id;
DROP INDEX IF EXISTS idx_career_quiz_responses_user_id;
DROP INDEX IF EXISTS idx_catchup_summaries_employee_id;
DROP INDEX IF EXISTS idx_copilot_conversation_history_user_id;
DROP INDEX IF EXISTS idx_department_strategy_actions_assigned_to;
DROP INDEX IF EXISTS idx_department_strategy_actions_dept_strategy_id;
DROP INDEX IF EXISTS idx_department_strategy_approvals_approver_id;
DROP INDEX IF EXISTS idx_goals_user_id;
DROP INDEX IF EXISTS idx_job_family_competencies_competency_id;
DROP INDEX IF EXISTS idx_job_family_competencies_required_level_id;
DROP INDEX IF EXISTS idx_job_history_changed_by;
DROP INDEX IF EXISTS idx_job_history_job_family_id;
DROP INDEX IF EXISTS idx_job_history_user_id;
DROP INDEX IF EXISTS idx_one_to_one_goals_cdp_id;
DROP INDEX IF EXISTS idx_one_to_one_goals_created_by;
DROP INDEX IF EXISTS idx_one_to_one_goals_user_id;
DROP INDEX IF EXISTS idx_profile_skills_skill_id;
DROP INDEX IF EXISTS idx_profiles_job_family_id;
DROP INDEX IF EXISTS idx_profiles_manager_id;
DROP INDEX IF EXISTS idx_review_actions_meeting_id;
DROP INDEX IF EXISTS idx_review_approvals_approver_id;
DROP INDEX IF EXISTS idx_review_approvals_competency_assessment_id;
DROP INDEX IF EXISTS idx_review_competency_assessments_meeting_id;
DROP INDEX IF EXISTS idx_review_competency_ratings_recorded_by;
DROP INDEX IF EXISTS idx_review_competency_ratings_review_instance_id;
DROP INDEX IF EXISTS idx_review_cycles_focus_area_id;
DROP INDEX IF EXISTS idx_review_employee_actions_action_owner;
DROP INDEX IF EXISTS idx_review_employee_notes_employee_id;
DROP INDEX IF EXISTS idx_review_half_year_assessments_manager_id;
DROP INDEX IF EXISTS idx_review_instances_template_id;
DROP INDEX IF EXISTS idx_review_kpi_ratings_meeting_id;
DROP INDEX IF EXISTS idx_review_kpi_ratings_recorded_by;
DROP INDEX IF EXISTS idx_review_kpi_ratings_review_instance_id;
DROP INDEX IF EXISTS idx_review_kpi_ratings_template_kpi_id;
DROP INDEX IF EXISTS idx_review_meetings_manager_id;
DROP INDEX IF EXISTS idx_review_monthly_averages_manager_id;
DROP INDEX IF EXISTS idx_review_monthly_competency_scores_competency_id;
DROP INDEX IF EXISTS idx_review_monthly_competency_scores_manager_id;
DROP INDEX IF EXISTS idx_view_as_sessions_active;
DROP INDEX IF EXISTS idx_review_schedules_cycle_id;
DROP INDEX IF EXISTS idx_review_schedules_manager_id;
DROP INDEX IF EXISTS idx_review_summaries_review_instance_id;
DROP INDEX IF EXISTS idx_review_templates_creator_id;
DROP INDEX IF EXISTS idx_review_templates_department_id;
DROP INDEX IF EXISTS idx_review_weekly_kpi_ratings_kpi_id;
DROP INDEX IF EXISTS idx_review_weekly_kpi_ratings_manager_id;
DROP INDEX IF EXISTS idx_review_weekly_summaries_manager_id;
DROP INDEX IF EXISTS idx_reviews_reviewer_id;
DROP INDEX IF EXISTS idx_focus_areas_strategy;
DROP INDEX IF EXISTS idx_milestones_focus_area;
DROP INDEX IF EXISTS idx_leads_focus_area;
DROP INDEX IF EXISTS idx_dept_strategies_parent;
DROP INDEX IF EXISTS idx_kpis_strategy;
DROP INDEX IF EXISTS idx_standalone_department_strategies_owner_id;
DROP INDEX IF EXISTS idx_strategic_goals_assigned_by_id;
DROP INDEX IF EXISTS idx_strategic_goals_assigned_to_id;
DROP INDEX IF EXISTS idx_strategic_goals_parent_goal_id;
DROP INDEX IF EXISTS idx_strategic_roadmaps_owner_id;
DROP INDEX IF EXISTS idx_strategy_actions_created_by;
DROP INDEX IF EXISTS idx_strategy_kpis_focus_area_id;
DROP INDEX IF EXISTS idx_strategy_lead_assignments_assigned_by;
DROP INDEX IF EXISTS idx_strategy_leads_assigned_by;
DROP INDEX IF EXISTS idx_strategy_notifications_dept_strategy_id;
DROP INDEX IF EXISTS idx_strategy_notifications_strategy_id;
DROP INDEX IF EXISTS idx_system_settings_updated_by;
DROP INDEX IF EXISTS idx_training_completions_course_id;
DROP INDEX IF EXISTS idx_user_admin_permissions_permission_name;
DROP INDEX IF EXISTS idx_user_cvs_user_id;
DROP INDEX IF EXISTS idx_view_as_sessions_target_user_id;
DROP INDEX IF EXISTS idx_weekly_catchups_employee_id;
DROP INDEX IF EXISTS idx_weekly_catchups_manager_id;
DROP INDEX IF EXISTS idx_review_cycles_manager;
DROP INDEX IF EXISTS idx_review_cycle_members_employee;
DROP INDEX IF EXISTS idx_review_cycle_kpis_cycle;
DROP INDEX IF EXISTS idx_review_cycle_actions_cycle;
DROP INDEX IF EXISTS idx_review_employee_actions_employee;
DROP INDEX IF EXISTS idx_review_employee_actions_overdue;
DROP INDEX IF EXISTS idx_review_monthly_averages_employee;
DROP INDEX IF EXISTS idx_review_schedules_employee;
DROP INDEX IF EXISTS idx_cycle_kpis_cycle;
DROP INDEX IF EXISTS idx_scheduled_meetings_cycle;
DROP INDEX IF EXISTS idx_scheduled_meetings_employee;
DROP INDEX IF EXISTS idx_scheduled_meetings_manager;
DROP INDEX IF EXISTS idx_weekly_checkins_meeting;
DROP INDEX IF EXISTS idx_weekly_checkins_employee;
DROP INDEX IF EXISTS idx_monthly_reviews_meeting;
DROP INDEX IF EXISTS idx_monthly_reviews_employee;
DROP INDEX IF EXISTS idx_competency_ratings_review;
DROP INDEX IF EXISTS idx_actions_employee;
DROP INDEX IF EXISTS idx_actions_weekly_checkin;
DROP INDEX IF EXISTS idx_actions_monthly_review;
DROP INDEX IF EXISTS idx_half_year_reviews_employee;
DROP INDEX IF EXISTS idx_self_assessments_employee;
DROP INDEX IF EXISTS idx_moderation_queue_status;
DROP INDEX IF EXISTS idx_role_skills_job_dept;
DROP INDEX IF EXISTS idx_role_skills_skill;
DROP INDEX IF EXISTS idx_assessment_cycles_dates;
DROP INDEX IF EXISTS idx_employee_assessments_employee;
DROP INDEX IF EXISTS idx_employee_assessments_cycle;
DROP INDEX IF EXISTS idx_manager_assessments_employee;
DROP INDEX IF EXISTS idx_manager_assessments_manager;
DROP INDEX IF EXISTS idx_manager_assessments_cycle;
DROP INDEX IF EXISTS idx_discrepancies_employee;
DROP INDEX IF EXISTS idx_discrepancies_flagged;
DROP INDEX IF EXISTS idx_skill_discussions_review;
DROP INDEX IF EXISTS idx_skill_discussions_skill;
DROP INDEX IF EXISTS idx_dev_actions_employee;
DROP INDEX IF EXISTS idx_dev_actions_status;
DROP INDEX IF EXISTS idx_dev_actions_skill;
DROP INDEX IF EXISTS idx_dept_matrix_dept_title;
DROP INDEX IF EXISTS idx_dept_matrix_skill;
DROP INDEX IF EXISTS idx_workflow_cycle;
DROP INDEX IF EXISTS idx_workflow_employee;
DROP INDEX IF EXISTS idx_workflow_manager;
DROP INDEX IF EXISTS idx_workflow_status;
DROP INDEX IF EXISTS idx_employee_responses_workflow;
DROP INDEX IF EXISTS idx_employee_responses_employee;
DROP INDEX IF EXISTS idx_manager_responses_workflow;
DROP INDEX IF EXISTS idx_manager_responses_manager;
DROP INDEX IF EXISTS idx_approvals_workflow;
DROP INDEX IF EXISTS idx_notifications_recipient;
DROP INDEX IF EXISTS idx_career_quiz_sessions_user;
DROP INDEX IF EXISTS idx_career_external_quals_user;
DROP INDEX IF EXISTS idx_career_skill_ratings_session;
DROP INDEX IF EXISTS idx_marti_coaching_user;
DROP INDEX IF EXISTS idx_marti_coaching_session;
DROP INDEX IF EXISTS idx_career_plans_quiz_session;